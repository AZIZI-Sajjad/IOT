
#ifndef _W5500LWIP_H
#define _W5500LWIP_H

#include <LwipIntfDev.h>
#include <utility/w5500.h>

using Wiznet5500lwIP = LwipIntfDev<Wiznet5500>;

#endif // _W5500LWIP_H
